

#!/usr/bin/env python

import socket

host = '192.168.1.13'
port = 9292
obj = socket.socket()
obj.connect((host, port))
 
print("CONNECTED")
 
while True:
    mens = raw_input("MESSAGE TO THE SERVER >> ")
    obj.send(mens)

obj.close()







